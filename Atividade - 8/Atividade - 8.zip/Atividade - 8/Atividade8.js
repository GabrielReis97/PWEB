let COOtimo = Number(localStorage.getItem("COOtimo")) || 0;
let COBom = Number(localStorage.getItem("COBom")) || 0;
let CORegular = Number(localStorage.getItem("CORegular")) || 0;
let COPessimo = Number(localStorage.getItem("COPessimo")) || 0;
let Masculino = Number(localStorage.getItem("Masculino")) || 0;
let Feminino = Number(localStorage.getItem("Feminino")) || 0;
let Outro = Number(localStorage.getItem("Outro")) || 0;
let quantPessoas = Number(localStorage.getItem("quantPessoas")) || 0;
let somaIdade = Number(localStorage.getItem("somaIdade")) || 0;
let maisVelho = Number(localStorage.getItem("maisVelho")) || 0;
let maisNovo = Number(localStorage.getItem("maisNovo")) || 999999999;
let MediaIdade;
let porcentagem;

function EnviarPesquisa() {
    let TextoSexo = "";
    let TextoOpniao = "";
    const idade = document.getElementById("Idade").value;
    const sexo = document.querySelector('input[name="Sexo"]:checked');
    const opiniao = document.querySelector('input[name="opniao"]:checked');

    if (idade === "" || !sexo || !opiniao) {
        alert("Por favor, preencha todos os campos antes de enviar!");
        return false;
    } 
    else {
        let idadeNum = Number(idade);

        quantPessoas = quantPessoas + 1;
        somaIdade = somaIdade + idadeNum;

        if (idadeNum > maisVelho) {
            maisVelho = idadeNum;
        }
        if (idadeNum < maisNovo) {
            maisNovo = idadeNum;
        }

        switch (sexo.value) {
            case "1": 
                Feminino++;
                TextoSexo = "Feminino";
                break;
            case "2": 
                Masculino++;
                TextoSexo = "Masculino";
                break;
            case "3": 
                Outro++;
                TextoSexo = "Outro";
                break;
        }

        switch (opiniao.value) {
            case "4": 
                COOtimo++;
                TextoOpniao = "Otimo";
                break;
            case "3": 
                COBom++;
                TextoOpniao = "Bom";
                break;
            case "2": 
                CORegular++;
                TextoOpniao = "Regular";
                break;
            case "1": 
                COPessimo++;
                TextoOpniao = "Pessimo";
                break;
        }

        MediaIdade = somaIdade / quantPessoas;
        porcentagem = ((COOtimo + COBom) / quantPessoas) * 100;


        localStorage.setItem("COOtimo", COOtimo);
        localStorage.setItem("COBom", COBom);
        localStorage.setItem("CORegular", CORegular);
        localStorage.setItem("COPessimo", COPessimo);
        localStorage.setItem("Masculino", Masculino);
        localStorage.setItem("Feminino", Feminino);
        localStorage.setItem("Outro", Outro);
        localStorage.setItem("quantPessoas", quantPessoas);
        localStorage.setItem("somaIdade", somaIdade);
        localStorage.setItem("maisVelho", maisVelho);
        localStorage.setItem("maisNovo", maisNovo);

        alert("Pesquisa Enviada e Salva com Sucesso!\n" +
            "Idade: " + idadeNum + "\n" +
            "Sexo: " + TextoSexo + "\n" +
            "Nota da Opinião: " + TextoOpniao + "\n\n" +
            "Idade Média geral: " + MediaIdade.toFixed(2) + "\n" +
            "Mais Velho: " + maisVelho + "\n" +
            "Mais Novo: " + maisNovo + "\n" +
            "Péssimos: " + COPessimo + "\n" +
            "Porcentagem Ótimo/Bom: " + porcentagem.toFixed(2) + "%\n" +
            "Masculino: " + Masculino + " | Feminino: " + Feminino + " | Outro: " + Outro);
         
         document.forms.elements[0].value = "";
        
        return false;
    }
}



function LimparDados() {
    if (confirm("Tem certeza que deseja apagar todas as estatísticas salvas?")) {
        localStorage.clear(); 
        location.reload(); 
    }
}