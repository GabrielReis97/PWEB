function transformar() {
  var texto = document.getElementById('campoTexto').value;
  var opcao = document.querySelector('input[name="opcao"]:checked');
  var resultado = document.getElementById('resultado');

  if (!opcao || texto.trim() === '') {
    resultado.textContent = '—';
    return;
  }

  if (opcao.value === 'maiusculas') {
    resultado.textContent = texto.toUpperCase();
  } else {
    resultado.textContent = texto.toLowerCase();
  }
}
